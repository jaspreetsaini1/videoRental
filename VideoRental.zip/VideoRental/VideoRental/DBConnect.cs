﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VideoRental
{
   public class DBConnect
    {

        String connsetting = System.Configuration.ConfigurationManager.ConnectionStrings["con"].ToString();
        SqlConnection dataConn = new SqlConnection();

        public SqlConnection DataConnection()
        {
            dataConn = new SqlConnection(connsetting);
            return dataConn;

        }
        public void SqlOpen()
        {
            try
            {
                dataConn.Open();
            }
            catch (Exception e)
            {

            }


        }
        public void SqlClose()
        {
            dataConn.Close();
            dataConn.Dispose();
        }
    }
}
