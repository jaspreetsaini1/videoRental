﻿using System;
using System.Data;
using System.Data.SqlClient;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoRental;

namespace VideoRentalTest
{
    [TestClass]
    public class UnitTest1
    {
        /// <summary>
        /// test with incorrect details of login
        /// </summary>
        [TestMethod]
        public void Test_LoginWithIncorrectCorrectCredentails()
        {
            var loginID = "admin";
            var password = "Admin@12344";
            string expectedString = System.Configuration.ConfigurationManager.ConnectionStrings["con"].ConnectionString;

            SqlConnection con = new SqlConnection(expectedString);
            SqlDataAdapter da = new SqlDataAdapter("userLogin", con);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@userid", SqlDbType.VarChar).Value = loginID;
            da.SelectCommand.Parameters.Add("@pwd", SqlDbType.VarChar).Value = password;
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt != null && dt.Rows.Count > 0)
                Assert.IsTrue(true);
            else
                Assert.IsFalse(false);
        }

        /// <summary>
        /// DB connection 
        /// </summary>
        [TestMethod]
        public void Test_GetConnStringFromAppConfig()
        {
            DataAccess da = new DataAccess();
            string actualString = da.connection;
            string expectedString = System.Configuration.ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            Assert.AreEqual(expectedString, actualString);

        }
    }
}
